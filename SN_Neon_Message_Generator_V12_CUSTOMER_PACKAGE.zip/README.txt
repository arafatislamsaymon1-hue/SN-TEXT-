﻿SN DIGITAL STUDIO
NEON MESSAGE GENERATOR

Product Version: 12.0
Developer: SN Digital Studio
Creator: Saymon

ABOUT:
SN Neon Message Generator is a Windows desktop application
created by SN Digital Studio.

INSTALLATION:
1. Extract the downloaded ZIP.
2. Open the extracted folder.
3. Double-click SNNeonMessageGenerator.exe.

USAGE:
1. Launch the application.
2. Select your available options.
3. Select the desired drive and generation mode.
4. Use the application's Generate controls.

IMPORTANT:
Check available disk space before generating large amounts
of data. Choose settings appropriate for your computer.

ABOUT THE CREATOR:
Saymon is an independent software creator interested in
programming, technology, and building useful applications.

PURCHASE:
One-time purchase. Lifetime free updates for this product,
according to the applicable purchase terms.

For more information, read the included documentation.
